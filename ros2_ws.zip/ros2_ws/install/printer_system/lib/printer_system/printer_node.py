#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from printer_system.srv import PrintJob
import time
from collections import deque

class PrinterNode(Node):
    def __init__(self):
        super().__init__('printer_node')
        self.jobs = deque()    
        self.service = self.create_service(PrintJob,'print_job',self.make_queue)

        
        self.status = self.create_publisher(String,'print_job',10)
        self.get_logger().info("PrinterNode is running")


    def make_queue(self, request, response):
        doc = request.document_name
        self.get_logger().info(f"Received request: {doc}") 
        self.jobs.append(doc)  
        self.pub_status(f"job queued:{doc}")
    
    
        doc = self.jobs.popleft()
        self.pub_status(f"processing job:{doc}")
        self.get_logger().info(f"processing job:{doc}")
        self.get_logger().info("printing")
        for i in range(2):
            time.sleep(1)
            self.get_logger().info("...")

        self.pub_status(f"completed processing:{doc}")
        self.get_logger().info(f"completed processing:{doc}")
        
        response.accepted =True
        return response   


    def pub_status(self, message):
        msg = String()
        msg.data = message
        self.status.publish(msg)
       
        
def main(args=None):
    rclpy.init(args=args)
    node = PrinterNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    
if  __name__=="__main__":
    main()
        