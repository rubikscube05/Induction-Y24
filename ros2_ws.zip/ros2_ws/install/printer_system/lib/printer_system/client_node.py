#!/usr/bin/env python3
import rclpy
import time
from rclpy.node import Node
from printer_system.srv import PrintJob

class JobClient(Node):
    def __init__(self):
        super().__init__('print_client')
        self.cli = self.create_client(PrintJob, 'print_job')
        
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('waiting for service ...')
            
        doc = input("enter doc name: ")
        request = PrintJob.Request()
        request.document_name = doc
        
        self.future =self .cli.call_async(request)
        self.future.add_done_callback(self.print_response)
    
    
    def print_response(self, future):
        print("Callback triggered") 
        if future.result() is not None:
            response = future.result()
            if response.accepted:
                self.get_logger().info("JOB ACCEPTED")
            else:
                self.get_logger().info("REJECTED")
                
        else:
            
            self.get_logger().info("service call failed")


def main(args=None):
    rclpy.init(args=args)
    
    node = JobClient()
    
    # Spin until the future is done
    while rclpy.ok() and not node.future.done():
        rclpy.spin_once(node)
    
    # Optional: ensure logger flushes
    time.sleep(0.1)
    
    node.destroy_node()
    rclpy.shutdown()

    
    
if __name__=='__main__':
    main()                       
        
        
    
    
           
        